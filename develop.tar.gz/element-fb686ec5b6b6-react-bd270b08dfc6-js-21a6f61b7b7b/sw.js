self.addEventListener('fetch', () => {});
